<div class="bg-footer">
        <img src="assets_user/img/footer-bg.webp" class="img-responsion" alt="Lofi Nest">
</div>